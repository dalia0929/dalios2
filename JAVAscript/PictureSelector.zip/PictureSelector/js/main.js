

/***********************************************************************************/
/* *********************************** DATA *************************************/
/***********************************************************************************/
// is photo-list isrenka li elementus
var items = document.getElementById('photo-list').getElementsByTagName('li');


/***********************************************************************************/
/* ********************************** FUNCTIONS ************************************/
/***********************************************************************************/
// "this" egzistuoja kiekvienam evente konkrecioje funcijoje. Konkreciam atvejui - li elementui.
function onMouseClick(){
 	this.classList.toggle('selected');
 	var selected = document.getElementsByClassName('selected'); //sukuriam pazymetu pic masyva
 	var total = document.getElementById('total');
 	total.innerHTML = selected.length;
}


/************************************************************************************/
/* ******************************** MAIN CODE **********************************/
/************************************************************************************/
for(var i =0; i < items.length; i++){
	items[i].addEventListener('click', onMouseClick);
}

